<?php
echo '<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/final.css">
    <title>SUCCESS !!</title>
    <style>
        /* Tambahkan CSS untuk mengatur ukuran gambar */
        img {
            max-width: 30%;
            height: auto;
            display: block;
            margin: 0 auto;
        }
    </style>
</head>
<body>
<img src="https://images2.imgbox.com/8b/ed/hHmrpAqR_o.gif" alt="Error image">
<div class="btn1">
    <a class="error" href="dasboard.php">Log Out</a>
</div>
</body>
</html>';
?>
